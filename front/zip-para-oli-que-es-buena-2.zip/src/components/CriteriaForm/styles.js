import { makeStyles } from "@mui/styles";

const useStyles = makeStyles((theme) => ({
  form: {
    marginTop: theme.spacing(1),
    marginBottom: theme.spacing(3),
  },
}));

export default useStyles;
