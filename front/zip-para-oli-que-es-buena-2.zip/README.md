# Front BiciMap

## Instalar dependencias

`npm install`

## Correr front

`npm start`